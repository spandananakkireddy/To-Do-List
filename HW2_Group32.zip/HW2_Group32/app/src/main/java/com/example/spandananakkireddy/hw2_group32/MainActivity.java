package com.example.spandananakkireddy.hw2_group32;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Collections;
import java.util.LinkedList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    TextView tvtitle;
    TextView tvtaskdate;
    TextView tvtasktime;
    TextView tvtaskpriority;
    TextView tvnum;
    TextView tvnum2;
    ImageView imlast;
    ImageView imback;
    ImageView imedit, imdelete, imone, imfor, imcreate;
    Task task;
    static int reqcode = 100;
    static int reqcode_edit = 101;
    static String Main_Key = "maintask";
    String mtitle,mdate,mtime,mpriority;

    LinkedList<Task> tasklist = new LinkedList<Task>();
    Task edit = new Task();
    int flag = tasklist.size();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("View Tasks");

        tvtitle = (TextView) findViewById(R.id.tvtitle);
        tvtaskdate = (TextView) findViewById(R.id.tvtaskdate);
        tvtasktime = (TextView) findViewById(R.id.tvtasktime);
        tvtaskpriority = (TextView) findViewById(R.id.tvtaskpriority);
        tvnum = (TextView) findViewById(R.id.tvnum);
        tvnum2 = (TextView) findViewById(R.id.tvnum2);
        imlast = (ImageView) findViewById(R.id.imlast);
        imlast.setOnClickListener(this);
        imback = (ImageView) findViewById(R.id.imback);
        imback.setOnClickListener(this);
        imedit = (ImageView) findViewById(R.id.imedit);
        imedit.setOnClickListener(this);
        imdelete = (ImageView) findViewById(R.id.imdelete);
        imdelete.setOnClickListener(this);
        imone = (ImageView) findViewById(R.id.imone);
        imone.setOnClickListener(this);
        imfor = (ImageView) findViewById(R.id.imfor);
        imfor.setOnClickListener(this);
        imcreate = (ImageView) findViewById(R.id.imcreate);
        imcreate.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int length = tasklist.size();
        if(v.getId() == R.id.imcreate)
        {
            Intent intent = new Intent(MainActivity.this,CreateTaskActivity.class);
            startActivityForResult(intent,reqcode);

        }
        if(v.getId() == R.id.imlast)
        {
            flag = 0;
            setFields(flag);
        }
        else if(v.getId() ==R.id.imback){
            if(flag > 0 && flag <= length-1){
                flag = flag -1;
                setFields(flag);
            }else
                Toast.makeText(getApplicationContext(),"Current task is the first task", Toast.LENGTH_LONG).show();
        }
        else if(v.getId() ==R.id.imone){
            if(flag < length-1 &&flag >= 0){
                flag = flag +1;
                setFields(flag);
            }else
                Toast.makeText(getApplicationContext(),"Current task is the last task", Toast.LENGTH_LONG).show();
        }
        else if(v.getId() ==R.id.imfor){
            flag = length -1 ;
            setFields(flag);
        }

        if(v.getId() == R.id.imdelete){
            LinkedList<Task> removelist = new LinkedList<Task>();
            for(Task t : tasklist){
                if(t != null && task.getTitle().equals(t.getTitle())){
                    removelist.add(t);
                }
            }
            tasklist.removeAll(removelist);
            tvnum2.setText(String.valueOf(tasklist.size()));
            if(tasklist.isEmpty())
                Toast.makeText(getApplicationContext(),"Task list is empty", Toast.LENGTH_LONG).show();
            else {
                tasklist.getFirst();

                //setFields(flag = 0);
            }
        }
        if(v.getId() ==  R.id.imedit){
            mtitle =tvtitle.getText().toString();
            mdate = tvtaskdate.getText().toString();
            mtime = tvtasktime.getText().toString();
            mpriority = tvtaskpriority.getText().toString();
            Task t = new Task(mtitle,mdate,mtime,mpriority);
            Intent intent = new Intent(MainActivity.this,EditActivity.class);
            intent.putExtra(Main_Key,t);
            startActivityForResult(intent,reqcode_edit);
        }

    }





@Override
protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == reqcode) {
        if (resultCode == RESULT_OK) {
        if (data.getExtras().getSerializable(CreateTaskActivity.Task_Key) != null) {
        task = (Task) data.getExtras().getSerializable(CreateTaskActivity.Task_Key);
        tvtitle.setText(task.getTitle());
        tvtaskdate.setText(task.getDate());
        tvtasktime.setText(task.getTime());
        tvtaskpriority.setText(task.getPriority());
        tasklist.add(task);
        Collections.sort(tasklist, new DateComparator());
        tvnum2.setText(String.valueOf(tasklist.size()));
        for(int i =1; i< tasklist.size();i++){
            tvnum.setText(String.valueOf(i));
        }
        //tvnum.setText(String.valueOf(tasklist.indexOf(task)+1));
        Log.d("demo", tasklist + "");
        }
        else if (requestCode == RESULT_CANCELED) {
        Log.d("demo", "error");
        }
        }
        }
        if(requestCode == reqcode_edit){
            if(resultCode == RESULT_OK){
                if (data.getExtras().getSerializable(EditActivity.Edit_Key) != null) {
                    task = (Task) data.getExtras().getSerializable(EditActivity.Edit_Key);
                    //tasklist.set(,task);
                }
                else if (requestCode == RESULT_CANCELED) {
                    Log.d("demo", "error");
                }
            }
        }

        }
        public void setFields(int key){
        tvtitle.setText(tasklist.get(key).getTitle());
            tvtaskdate.setText(tasklist.get(key).getDate());
            tvtasktime.setText(tasklist.get(key).getTime());
            tvtaskpriority.setText(tasklist.get(key).getPriority());
        }


        }
