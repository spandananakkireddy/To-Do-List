package com.example.spandananakkireddy.hw2_group32;

import java.util.Comparator;

/**
 * Created by Spandana Nakkireddy on 2/1/2018.
 */

public class DateComparator implements Comparator<Task> {
    @Override
    public int compare(Task o1, Task o2) {
        if(o1.getDate().equals(o2.getDate())){
            return o1.getTime().toString().compareTo(o2.getTime().toString());
        }else
        return (int) (o1.getDate().toString().compareTo(o2.getDate().toString()));

    }
}
